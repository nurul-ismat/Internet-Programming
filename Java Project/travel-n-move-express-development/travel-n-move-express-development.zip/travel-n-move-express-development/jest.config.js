module.exports = {
  // testEnvironment: "node",
  testEnvironment: "./tests/config/test_environment",
  globalSetup: "./tests/config/setup.js",
  globalTeardown: "./tests/config/teardown.js"
};
